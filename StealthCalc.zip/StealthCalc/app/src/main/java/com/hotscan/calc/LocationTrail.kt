package com.hotscan.calc

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle

/**
 * Logs a timestamped location trail and adapts to save battery:
 *  - MOVING: full-power GPS at the configured interval.
 *  - STILL: low-power network location at a much longer interval.
 * It switches based on the distance between consecutive fixes, so GPS isn't hammered
 * every few seconds while the phone sits on a table.
 * Requires ACCESS_FINE_LOCATION (already requested).
 */
@SuppressLint("MissingPermission")
class LocationTrail(
    private val context: Context,
    private val cb: SignalCallback,
    intervalMs: Long = 10_000,
    private val awayDetect: Boolean = false,
    private val homeLat: Float = Float.NaN,
    private val homeLon: Float = Float.NaN
) : Scanner {

    private val baseMs = intervalMs.coerceAtLeast(5_000)
    private val stillMs = (baseMs * 6).coerceAtLeast(60_000)
    private val stillDistM = 20f      // moved less than this between fixes = "still"
    private val stillHitsToIdle = 3   // consecutive still fixes before going low-power

    private val lm = context.applicationContext
        .getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private var running = false
    private var moving = true
    private var stillCount = 0
    private var lastLat: Double? = null
    private var lastLon: Double? = null
    private var wasAway: Boolean? = null

    private val listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            val alt = if (loc.hasAltitude()) "%.0f".format(loc.altitude) else "?"
            val spd = if (loc.hasSpeed()) "%.1f".format(loc.speed) else "?"
            val acc = if (loc.hasAccuracy()) "%.0f".format(loc.accuracy) else "?"
            cb(
                "GPS",
                "%.6f, %.6f  alt=%sm spd=%sm/s acc=%sm  (%s)".format(
                    loc.latitude, loc.longitude, alt, spd, acc, loc.provider
                ),
                false
            )
            adaptMode(loc)
            if (awayDetect && !homeLat.isNaN() && !homeLon.isNaN()) checkAway(loc)
        }
        override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
        override fun onProviderEnabled(p: String) {}
        override fun onProviderDisabled(p: String) {}
    }

    override fun start() {
        if (running) return
        running = true
        requestForMode()
    }

    override fun stop() {
        running = false
        try { lm.removeUpdates(listener) } catch (_: Exception) {}
    }

    /** (Re)register updates for the current mode. */
    private fun requestForMode() {
        try { lm.removeUpdates(listener) } catch (_: Exception) {}
        val gps = LocationManager.GPS_PROVIDER
        val net = LocationManager.NETWORK_PROVIDER
        try {
            if (moving) {
                when {
                    lm.isProviderEnabled(gps) -> lm.requestLocationUpdates(gps, baseMs, 0f, listener)
                    lm.isProviderEnabled(net) -> lm.requestLocationUpdates(net, baseMs, 0f, listener)
                }
            } else {
                when {
                    lm.isProviderEnabled(net) -> lm.requestLocationUpdates(net, stillMs, 0f, listener)
                    lm.isProviderEnabled(gps) -> lm.requestLocationUpdates(gps, stillMs, 0f, listener)
                }
            }
        } catch (_: SecurityException) {
            cb("GPS", "Missing permission for location updates.", false)
        } catch (_: Exception) {}
    }

    private fun adaptMode(loc: Location) {
        val pLat = lastLat; val pLon = lastLon
        if (pLat != null && pLon != null) {
            val d = FloatArray(1)
            Location.distanceBetween(pLat, pLon, loc.latitude, loc.longitude, d)
            if (d[0] < stillDistM) {
                stillCount++
                if (moving && stillCount >= stillHitsToIdle) {
                    moving = false
                    cb("GPS", "still → low-power location (every ${stillMs / 1000}s)", false)
                    requestForMode()
                }
            } else {
                stillCount = 0
                if (!moving) {
                    moving = true
                    cb("GPS", "motion detected → GPS (every ${baseMs / 1000}s)", false)
                    requestForMode()
                }
            }
        }
        lastLat = loc.latitude
        lastLon = loc.longitude
    }

    private fun checkAway(loc: Location) {
        val d = FloatArray(1)
        Location.distanceBetween(
            loc.latitude, loc.longitude, homeLat.toDouble(), homeLon.toDouble(), d
        )
        val away = d[0] > 150f
        if (wasAway == null) {
            wasAway = away
            cb("GEO", if (away) "Starting away from home (${d[0].toInt()}m)" else "Starting at home", false)
        } else if (away != wasAway) {
            wasAway = away
            cb("ALERT", if (away) "⚠ Left home geofence (${d[0].toInt()}m away)"
                        else "Returned to home geofence", true)
        }
    }
}
