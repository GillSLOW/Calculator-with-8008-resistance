package com.hotscan.calc

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Appends scan results to a log file in the app's external files directory:
 *   Android/data/com.hotscan.calc/files/logs/<name>
 * This location needs no storage permission and survives app restarts.
 * The same file is reused for every session until the name is changed in Settings.
 */
class SignalLogger(context: Context, fileName: String) {

    private val dir = File(context.getExternalFilesDir(null), "logs").apply { mkdirs() }
    private val file = File(dir, sanitize(fileName))
    private val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
    private val lock = Any()
    private var writeCount = 0

    val path: String get() = file.absolutePath

    fun writeHeader() {
        append("==== Session started ${ts.format(Date())} ====")
    }

    /** category e.g. WIFI / BT / BLE / CELL / ALERT */
    fun log(category: String, message: String) {
        append("${ts.format(Date())}\t$category\t$message")
    }

    private fun append(line: String) {
        synchronized(lock) {
            try {
                file.appendText(line + "\n")
                // Check size occasionally (not every write) and rotate when it gets large.
                if (++writeCount >= CHECK_EVERY) {
                    writeCount = 0
                    if (file.length() > MAX_BYTES) rotate()
                }
            } catch (_: Exception) {
                // Logging is best-effort; never crash the scan loop on an I/O error.
            }
        }
    }

    /** Rename the current file to "<name>.1" (keeping one backup) and start a fresh file. */
    private fun rotate() {
        try {
            val backup = File(dir, file.name + ".1")
            if (backup.exists()) backup.delete()
            file.renameTo(backup)
            // Next append() recreates the primary file automatically.
            File(file.absolutePath).appendText(
                "==== Rotated ${ts.format(Date())} (previous saved as ${backup.name}) ====\n"
            )
        } catch (_: Exception) {}
    }

    private fun sanitize(name: String): String {
        val cleaned = name.trim().ifEmpty { Prefs.DEFAULT_LOG }
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
        return if (cleaned.contains(".")) cleaned else "$cleaned.log"
    }

    companion object {
        private const val MAX_BYTES = 5L * 1024 * 1024 // rotate at 5 MB
        private const val CHECK_EVERY = 100            // stat the file every N writes
    }
}
