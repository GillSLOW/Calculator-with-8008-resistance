package com.hotscan.calc

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import android.os.PowerManager

/**
 * Bluetooth scanning: classic discovery + BLE advertisements.
 *
 * Background behaviour (the important part for tracker/follower detection):
 *  - An UNFILTERED BLE scan is paused by Android whenever the screen is off (since 8.1),
 *    and any scan is throttled after ~30 min. So:
 *      • Screen ON  → unfiltered scan (logs every nearby device).
 *      • Screen OFF → FILTERED scan on the tracker signatures, which Android keeps running
 *        in the background, so AirTag/Tile/SmartTag and follower alerts still fire.
 *  - The LE scan is also restarted every ~25 min to dodge the long-running cutback.
 */
@SuppressLint("MissingPermission") // permissions requested at runtime by ScannerActivity
class BtScanner(
    private val context: Context,
    private val cb: SignalCallback,
    intervalMs: Long = 20_000,
    private val trackerDetect: Boolean = false,
    private val followerDetect: Boolean = false
) : Scanner {

    private val period = intervalMs.coerceAtLeast(12_000)
    private val leRestartMs = 25L * 60_000
    private val manager = context.applicationContext
        .getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager?
    private val adapter: BluetoothAdapter? = manager?.adapter
    private val power = context.applicationContext
        .getSystemService(Context.POWER_SERVICE) as PowerManager?
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var foundReceiver: BroadcastReceiver? = null
    private var screenReceiver: BroadcastReceiver? = null
    private var leFiltered = false
    private var lastLeRestart = 0L

    // Background filtering is only worth doing if we're trying to catch trackers/followers.
    private val needBackground get() = trackerDetect || followerDetect

    private data class Sighting(var first: Long, var last: Long, var count: Int, var flagged: Boolean)
    private val seen = HashMap<String, Sighting>()

    // Per-interval aggregation: one summary line per device per flush instead of logging
    // every advertisement (which fires many times a second per device).
    private data class Win(var name: String, var count: Int, var best: Int, val category: String)
    private val window = HashMap<String, Win>()
    private val winLock = Any()
    private val NO_RSSI = Int.MIN_VALUE

    // Tracker candidates: a Find My / Tile / SmartTag beacon is only alerted on once it has
    // stayed with you over time AND across multiple locations — the way Apple's and Google's
    // own unknown-tracker alerts work — so ordinary passing iPhones/AirPods don't trip it.
    private val lm = context.applicationContext
        .getSystemService(Context.LOCATION_SERVICE) as LocationManager?
    private data class TrackerCand(
        val first: Long, var last: Long, val locs: HashSet<String>, var kind: String, var alerted: Boolean
    )
    private val trackerCandidates = HashMap<String, TrackerCand>()
    private val trackerLock = Any()
    private val TRACKER_MIN_DURATION_MS = 15L * 60_000 // must stay with you ≥ 15 min
    private val TRACKER_MIN_LOCATIONS = 3              // seen at ≥ 3 distinct ~100 m places
    private val TRACKER_STALE_MS = 30L * 60_000        // drop candidates not seen for 30 min

    private val leCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            result ?: return
            val dev = result.device
            val name = safeName(dev) ?: result.scanRecord?.deviceName ?: "<unknown>"
            val addr = dev.address
            val rssi = result.rssi
            synchronized(winLock) {
                val w = window[addr]
                if (w == null) window[addr] = Win(name, 1, rssi, "BLE")
                else {
                    w.count++
                    if (rssi > w.best) w.best = rssi
                    if (name != "<unknown>") w.name = name
                }
            }
            // Note tracker-type beacons as candidates; alert only once persistence is proven.
            if (trackerDetect) {
                val kind = trackerKind(result)
                if (kind != null) noteTracker(addr, kind)
            }
        }
    }

    private val periodic = object : Runnable {
        override fun run() {
            flushWindow()
            try { if (adapter?.isDiscovering == false) adapter.startDiscovery() } catch (_: Exception) {}
            if (trackerDetect) evaluateTrackers()
            if (followerDetect) evaluateFollowers()
            // Restart the LE scan periodically so Android doesn't throttle a long-running scan.
            if (System.currentTimeMillis() - lastLeRestart > leRestartMs) applyLeMode()
            if (running) handler.postDelayed(this, period)
        }
    }

    /** Emit one summary line per device seen this interval, then reset the window. */
    private fun flushWindow() {
        val batch: List<Pair<String, Win>>
        synchronized(winLock) {
            batch = window.map { it.key to it.value }
            window.clear()
        }
        for ((addr, w) in batch) {
            val sig = if (w.best == NO_RSSI) "n/a" else "${w.best}dBm"
            cb(w.category, "${w.name}  $addr  best=$sig  x${w.count}", false)
            if (followerDetect) record(addr, w.name)
        }
    }

    override fun start() {
        if (running) return
        val a = adapter
        if (a == null) { cb("BT", "No Bluetooth adapter on this device.", false); return }
        if (!a.isEnabled) { cb("BT", "Bluetooth radio is off — enable it for scanning.", false); return }
        running = true

        foundReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i?.action == BluetoothDevice.ACTION_FOUND) {
                    val dev: BluetoothDevice? = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    val rssi = i.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE)
                    dev ?: return
                    val name = safeName(dev) ?: "<unknown>"
                    val addr = dev.address
                    synchronized(winLock) {
                        val w = window[addr]
                        if (w == null) {
                            window[addr] = Win(name, 1, if (rssi != Short.MIN_VALUE) rssi.toInt() else NO_RSSI, "BT")
                        } else {
                            w.count++
                            if (rssi != Short.MIN_VALUE && rssi > w.best) w.best = rssi.toInt()
                            if (name != "<unknown>") w.name = name
                        }
                    }
                }
            }
        }
        context.registerReceiver(foundReceiver, IntentFilter(BluetoothDevice.ACTION_FOUND))

        // Switch scan filtering when the screen turns on/off.
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                when (i?.action) {
                    Intent.ACTION_SCREEN_OFF, Intent.ACTION_SCREEN_ON -> applyLeMode()
                }
            }
        }
        context.registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        })

        applyLeMode()
        handler.post(periodic)
    }

    override fun stop() {
        running = false
        handler.removeCallbacks(periodic)
        try { adapter?.cancelDiscovery() } catch (_: Exception) {}
        try { adapter?.bluetoothLeScanner?.stopScan(leCallback) } catch (_: Exception) {}
        foundReceiver?.let { try { context.unregisterReceiver(it) } catch (_: Exception) {} }
        screenReceiver?.let { try { context.unregisterReceiver(it) } catch (_: Exception) {} }
        foundReceiver = null
        screenReceiver = null
        synchronized(winLock) { window.clear() }
        synchronized(trackerLock) { trackerCandidates.clear() }
    }

    /** (Re)start the LE scan: unfiltered when the screen is on, filtered to the tracker types
     *  when the screen is off (so it keeps running in the background). */
    private fun applyLeMode() {
        val scanner = adapter?.bluetoothLeScanner ?: return
        val interactive = power?.isInteractive ?: true
        val filtered = needBackground && !interactive

        try { scanner.stopScan(leCallback) } catch (_: Exception) {}

        val filters = if (filtered) trackerFilters() else null // null = unfiltered
        val settings = ScanSettings.Builder()
            .setScanMode(if (filtered) ScanSettings.SCAN_MODE_LOW_POWER else ScanSettings.SCAN_MODE_BALANCED)
            .build()
        try {
            scanner.startScan(filters, settings, leCallback)
            if (filtered != leFiltered) {
                cb("BT", if (filtered) "screen off → filtered tracker scan (background)"
                         else "screen on → full BLE scan", false)
            }
            leFiltered = filtered
            lastLeRestart = System.currentTimeMillis()
        } catch (_: Exception) {}
    }

    /** ScanFilters for the tracker types. A filtered scan is what Android lets run with the
     *  screen off, so these are what keep background tracker detection alive. */
    private fun trackerFilters(): List<ScanFilter> {
        val base = "-0000-1000-8000-00805F9B34FB"
        fun svc(v: Int) = ParcelUuid.fromString("0000%04X".format(v and 0xFFFF) + base)
        return listOf(
            // Apple Find My / AirTag offline-finding (manufacturer 0x004C, type byte 0x12)
            ScanFilter.Builder()
                .setManufacturerData(0x004C, byteArrayOf(0x12), byteArrayOf(0xFF.toByte()))
                .build(),
            ScanFilter.Builder().setServiceUuid(svc(0xFEED)).build(), // Tile
            ScanFilter.Builder().setServiceUuid(svc(0xFEEC)).build(), // Tile
            ScanFilter.Builder().setServiceUuid(svc(0xFD5A)).build(), // Samsung SmartTag
            ScanFilter.Builder().setManufacturerData(0x0075, ByteArray(0)).build() // Samsung
        )
    }

    /** Returns the tracker family if this advertisement looks like one, else null. Note this
     *  matches ordinary iPhones/AirPods too (they share the Find My signal) — persistence is
     *  what distinguishes an actual tracker following you. */
    private fun trackerKind(result: ScanResult): String? {
        val rec = result.scanRecord ?: return null
        val apple = rec.getManufacturerSpecificData(0x004C)
        if (apple != null && apple.isNotEmpty() && (apple[0].toInt() and 0xFF) == 0x12) return "Apple Find My"
        val uuids = rec.serviceUuids
        if (uuids != null) {
            if (uuids.any { it.matches16(0xFEED) || it.matches16(0xFEEC) }) return "Tile"
            if (uuids.any { it.matches16(0xFD5A) }) return "Samsung SmartTag"
        }
        if (rec.getManufacturerSpecificData(0x0075) != null) return "Samsung"
        return null
    }

    private fun noteTracker(addr: String, kind: String) {
        val now = System.currentTimeMillis()
        val bucket = locationBucket()
        synchronized(trackerLock) {
            val c = trackerCandidates.getOrPut(addr) { TrackerCand(now, now, HashSet(), kind, false) }
            c.last = now
            c.kind = kind
            if (bucket != null) c.locs.add(bucket)
        }
    }

    /** Alert on a candidate only once it has been with us long enough AND across enough
     *  distinct locations — ~100 m buckets — so you must have actually moved while it stayed. */
    private fun evaluateTrackers() {
        val now = System.currentTimeMillis()
        val toAlert = ArrayList<Pair<String, TrackerCand>>()
        synchronized(trackerLock) {
            val it = trackerCandidates.entries.iterator()
            while (it.hasNext()) {
                val e = it.next()
                val c = e.value
                if (now - c.last > TRACKER_STALE_MS) { it.remove(); continue }
                if (!c.alerted && (c.last - c.first) >= TRACKER_MIN_DURATION_MS &&
                    c.locs.size >= TRACKER_MIN_LOCATIONS
                ) {
                    c.alerted = true
                    toAlert.add(e.key to c)
                }
            }
        }
        for ((addr, c) in toAlert) {
            cb(
                "ALERT",
                "⚠ Possible tracker following you: ${c.kind}  $addr  " +
                    "(${(c.last - c.first) / 60_000}min, ${c.locs.size} locations)",
                true
            )
        }
    }

    /** Current coarse location bucketed to ~100 m, or null if unknown. Uses last known fix
     *  (no new GPS work). */
    private fun locationBucket(): String? {
        val loc = try {
            lm?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        } catch (_: SecurityException) { null } catch (_: Exception) { null }
        loc ?: return null
        return "%.3f,%.3f".format(loc.latitude, loc.longitude)
    }

    private fun ParcelUuid.matches16(v: Int): Boolean {
        val s = uuid.toString().lowercase()
        val hex = "%04x".format(v and 0xFFFF)
        return s.startsWith("0000$hex-")
    }

    private fun record(addr: String, name: String) {
        val now = System.currentTimeMillis()
        val s = seen[addr]
        if (s == null) seen[addr] = Sighting(now, now, 1, false)
        else { s.last = now; s.count++ }
    }

    private fun evaluateFollowers() {
        val now = System.currentTimeMillis()
        for ((addr, s) in seen) {
            val span = s.last - s.first
            if (!s.flagged && span > 10 * 60_000L && s.count >= 5 && (now - s.last) < period * 2) {
                s.flagged = true
                cb("ALERT", "⚠ Device persists ${span / 60_000}min (possible follower)  $addr", true)
            }
        }
    }

    private fun safeName(dev: BluetoothDevice): String? = try {
        dev.name?.takeIf { it.isNotBlank() }
    } catch (_: Exception) { null }
}
